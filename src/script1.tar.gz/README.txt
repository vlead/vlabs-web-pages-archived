Name and id of the values which have to be prefilled must be same.

Example :- <input type="text" id="name" name="name">
