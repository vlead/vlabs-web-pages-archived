Just add this line in the head section of the html page and give permissions to the file:

"<?php include("counter.php"); ?>"
