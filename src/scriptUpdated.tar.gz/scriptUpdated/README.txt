Include this script in the head tag.
